NIRMALA TRUST FOUNDATION website
=================================

Files:
- index.html
- images/ (all uploaded images copied here)

Preview:
Open index.html in Chrome.

Publish on GitHub Pages:
1. Create/open a GitHub repository.
2. Upload index.html AND the complete images folder (keep the filenames unchanged).
3. In repository Settings > Pages, select Deploy from a branch, branch main, folder /(root), then Save.
4. Wait for the Pages URL to appear.

Note:
- This is a static informational website; enquiry form opens WhatsApp.
- No online donation/payment collection is enabled.
- Confirm the trust's legal registration details and all package details before publishing.
